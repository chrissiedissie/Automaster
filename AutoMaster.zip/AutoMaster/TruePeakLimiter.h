#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

// Lookahead true-peak limiter.
//  - True peak is estimated with 8x oversampling (windowed-sinc interpolation, 2*half taps).
//    8x is deliberately finer than the 4x of BS.1770, which can under-read by up to ~0.7 dB.
//  - The required gain is passed through a sliding minimum (window W), an instant-attack /
//    one-pole-release stage and a moving average of length W. This guarantees the applied
//    gain is never higher than what any peak inside the lookahead window requires.
//  - The audio is delayed by (W + half - 1) samples; report this as plugin latency.
class TruePeakLimiter
{
public:
    static constexpr int maxChannels = 2;
    static constexpr int half = 12;              // interpolation half width
    static constexpr int taps = 2 * half;        // taps per phase
    static constexpr int centreIndex = half - 1; // index of x[m] inside the history
    static constexpr int oversample = 8;
    static constexpr int phases = oversample - 1;
    static constexpr float safetyMarginDb = 0.3f;

    void prepare (double sampleRate, int numChannels, double lookaheadMs = 3.0)
    {
        fs = sampleRate;
        channels = juce::jlimit (1, maxChannels, numChannels);
        windowLen = juce::jmax (1, (int) std::lround (sampleRate * lookaheadMs * 0.001));
        latency = windowLen + half - 1;
        delayLen = latency + 1;
        dqCap = windowLen + 2;

        dqVal.assign ((size_t) dqCap, 1.0f);
        dqIdx.assign ((size_t) dqCap, 0);
        avgBuf.assign ((size_t) windowLen, 1.0f);
        for (int c = 0; c < maxChannels; ++c)
            delay[(size_t) c].assign ((size_t) delayLen, 0.0f);

        buildInterpolator();
        reset();
    }

    void reset()
    {
        for (int c = 0; c < maxChannels; ++c)
        {
            std::fill (delay[(size_t) c].begin(), delay[(size_t) c].end(), 0.0f);
            hist[(size_t) c].fill (0.0f);
        }

        std::fill (dqVal.begin(), dqVal.end(), 1.0f);
        std::fill (dqIdx.begin(), dqIdx.end(), (int64_t) 0);
        std::fill (avgBuf.begin(), avgBuf.end(), 1.0f);
        dqHead = 0;
        dqCount = 0;
        counter = 0;
        avgSum = (double) windowLen;
        avgPos = 0;
        relState = 1.0f;
        wp = 0;
        hpos = 0;
        lastGain = 1.0f;
    }

    int getLatencySamples() const noexcept { return latency; }
    float getLastGain() const noexcept { return lastGain; }

    void setCeilingDb (float db) noexcept { ceilingLin = std::pow (10.0f, (db - safetyMarginDb) / 20.0f); }

    void setReleaseMs (float ms) noexcept
    {
        releaseCoef = 1.0f - std::exp (-1.0f / (float) (fs * (double) ms * 0.001));
    }

    // In-place. x[0..channels-1] is one sample frame. If applyGain is false the audio is only delayed.
    void processFrame (float* x, bool applyGain)
    {
        // 1) update history and estimate the true peak of the sample m = t - half
        for (int c = 0; c < channels; ++c)
        {
            auto& h = hist[(size_t) c];
            h[(size_t) hpos] = x[c];
            h[(size_t) (hpos + taps)] = x[c];
        }
        hpos = (hpos + 1) % taps;

        float peak = 0.0f;
        for (int c = 0; c < channels; ++c)
        {
            const float* seq = hist[(size_t) c].data() + hpos; // oldest ... newest
            peak = juce::jmax (peak, std::abs (seq[centreIndex]));

            for (int p = 0; p < phases; ++p)
            {
                float acc = 0.0f;
                const auto& k = coef[(size_t) p];
                for (int i = 0; i < taps; ++i)
                    acc += seq[i] * k[(size_t) i];
                peak = juce::jmax (peak, std::abs (acc));
            }
        }

        // 2) required gain -> sliding minimum -> release -> moving average
        const float req = peak > ceilingLin ? ceilingLin / peak : 1.0f;
        const float gmin = pushMin (req);

        if (gmin < relState)
            relState = gmin;
        else
            relState += (gmin - relState) * releaseCoef;

        avgSum += (double) relState - (double) avgBuf[(size_t) avgPos];
        avgBuf[(size_t) avgPos] = relState;
        avgPos = (avgPos + 1) % windowLen;
        if (avgPos == 0) // recompute now and then so rounding errors never accumulate
        {
            double s = 0.0;
            for (float v : avgBuf)
                s += (double) v;
            avgSum = s;
        }
        const float gain = (float) (avgSum / (double) windowLen);
        lastGain = gain;

        // 3) delayed audio * gain
        for (int c = 0; c < channels; ++c)
            delay[(size_t) c][(size_t) wp] = x[c];

        const int rp = (wp + 1) % delayLen;
        for (int c = 0; c < channels; ++c)
        {
            float y = delay[(size_t) c][(size_t) rp];
            if (applyGain)
                y = juce::jlimit (-ceilingLin, ceilingLin, y * gain);
            x[c] = y;
        }
        wp = rp;
    }

private:
    float pushMin (float v)
    {
        while (dqCount > 0 && dqVal[(size_t) ((dqHead + dqCount - 1) % dqCap)] >= v)
            --dqCount;

        const int pos = (dqHead + dqCount) % dqCap;
        dqVal[(size_t) pos] = v;
        dqIdx[(size_t) pos] = counter;
        ++dqCount;

        while (dqIdx[(size_t) dqHead] <= counter - (int64_t) windowLen)
        {
            dqHead = (dqHead + 1) % dqCap;
            --dqCount;
        }

        ++counter;
        return dqVal[(size_t) dqHead];
    }

    void buildInterpolator()
    {
        const double pi = juce::MathConstants<double>::pi;

        for (int p = 1; p <= phases; ++p)
            for (int i = 0; i < taps; ++i)
            {
                const double k = (double) (i - centreIndex);
                const double u = k - (double) p / (double) oversample;
                const double s = std::abs (u) < 1.0e-9 ? 1.0 : std::sin (pi * u) / (pi * u);
                const double w = std::abs (u) < (double) half ? 0.5 + 0.5 * std::cos (pi * u / (double) half) : 0.0;
                coef[(size_t) (p - 1)][(size_t) i] = (float) (s * w);
            }
    }

    double fs = 44100.0;
    int channels = 2, windowLen = 1, latency = 0, delayLen = 1, dqCap = 3;
    float ceilingLin = 0.88f, releaseCoef = 0.001f, lastGain = 1.0f, relState = 1.0f;

    std::array<std::vector<float>, maxChannels> delay;
    std::array<std::array<float, 2 * taps>, maxChannels> hist {};
    std::array<std::array<float, taps>, phases> coef {};
    std::vector<float> dqVal, avgBuf;
    std::vector<int64_t> dqIdx;
    int dqHead = 0, dqCount = 0, avgPos = 0, wp = 0, hpos = 0;
    int64_t counter = 0;
    double avgSum = 0.0;
};

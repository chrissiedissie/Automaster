#include "PluginEditor.h"

AutoMasterAudioProcessorEditor::AutoMasterAudioProcessorEditor (AutoMasterAudioProcessor& p)
    : AudioProcessorEditor (&p), proc (p)
{
    setupKnob (targetKnob, "Target", "target", " LUFS");
    setupKnob (ceilingKnob, "Ceiling", "ceiling", " dBTP");
    setupKnob (maxGainKnob, "Max Gain", "maxgain", " dB");
    setupKnob (speedKnob, "Speed", "speed", " s");
    setupKnob (releaseKnob, "Release", "release", " ms");

    addAndMakeVisible (holdButton);
    addAndMakeVisible (bypassButton);
    holdAttachment = std::make_unique<ButtonAttachment> (proc.apvts, "hold", holdButton);
    bypassAttachment = std::make_unique<ButtonAttachment> (proc.apvts, "bypass", bypassButton);

    addAndMakeVisible (resetButton);
    resetButton.onClick = [this] { proc.resetRequested.store (true); };

    readout.setJustificationType (juce::Justification::centred);
    readout.setFont (juce::FontOptions (16.0f));
    addAndMakeVisible (readout);

    setSize (600, 340);
    startTimerHz (10);
}

void AutoMasterAudioProcessorEditor::setupKnob (Knob& k, const juce::String& text, const juce::String& paramId,
                                                const juce::String& suffix)
{
    k.slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    k.slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 90, 22);
    k.slider.setTextValueSuffix (suffix);
    addAndMakeVisible (k.slider);

    k.label.setText (text, juce::dontSendNotification);
    k.label.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (k.label);

    k.attachment = std::make_unique<SliderAttachment> (proc.apvts, paramId, k.slider);
}

void AutoMasterAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff1c1f26));
    g.setColour (juce::Colours::white);
    g.setFont (juce::FontOptions (22.0f, juce::Font::bold));
    g.drawText ("AutoMaster", 0, 8, getWidth(), 30, juce::Justification::centred);
}

void AutoMasterAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced (12);
    area.removeFromTop (34);
    readout.setBounds (area.removeFromTop (30));
    area.removeFromTop (8);

    auto buttons = area.removeFromBottom (36);
    holdButton.setBounds (buttons.removeFromLeft (140));
    bypassButton.setBounds (buttons.removeFromLeft (140));
    resetButton.setBounds (buttons.removeFromRight (100));

    Knob* knobs[] = { &targetKnob, &ceilingKnob, &maxGainKnob, &speedKnob, &releaseKnob };
    const int w = area.getWidth() / 5;
    for (auto* k : knobs)
    {
        auto col = area.removeFromLeft (w);
        k->label.setBounds (col.removeFromTop (22));
        k->slider.setBounds (col);
    }
}

void AutoMasterAudioProcessorEditor::timerCallback()
{
    const float st = proc.meterShortTerm.load();
    const juce::String stText = st > -90.0f ? juce::String (st, 1) + " LUFS-S" : juce::String ("waiting for signal");

    readout.setText ("Output: " + stText
                         + "   |   Auto gain: " + juce::String (proc.meterGainDb.load(), 1) + " dB"
                         + "   |   Limiter: -" + juce::String (proc.meterReductionDb.load(), 1) + " dB",
                     juce::dontSendNotification);
}

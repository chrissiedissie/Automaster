#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <atomic>
#include "LoudnessMeter.h"
#include "TruePeakLimiter.h"

class AutoMasterAudioProcessor : public juce::AudioProcessor
{
public:
    AutoMasterAudioProcessor();
    ~AutoMasterAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "AutoMaster"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

    juce::AudioProcessorValueTreeState apvts;

    // Read by the editor (GUI thread)
    std::atomic<float> meterShortTerm { -100.0f };
    std::atomic<float> meterGainDb { 0.0f };
    std::atomic<float> meterReductionDb { 0.0f };
    std::atomic<bool> resetRequested { false };

private:
    void updateControl (float targetLufs, float tauSeconds, float maxGainDb, bool hold, bool bypass);

    LoudnessMeter meter;
    TruePeakLimiter limiter;

    double sampleRateHz = 44100.0;
    float gainDb = 0.0f;         // slow, loudness-driven gain
    float gainTargetLin = 1.0f;
    float gainSmoothed = 1.0f;
    float smoothCoef = 0.001f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (AutoMasterAudioProcessor)
};

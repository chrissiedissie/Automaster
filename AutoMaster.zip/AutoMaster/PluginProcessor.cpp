#include "PluginProcessor.h"
#include "PluginEditor.h"

juce::AudioProcessorValueTreeState::ParameterLayout AutoMasterAudioProcessor::createLayout()
{
    using namespace juce;
    AudioProcessorValueTreeState::ParameterLayout layout;

    layout.add (std::make_unique<AudioParameterFloat> (ParameterID { "target", 1 }, "Target Loudness",
                                                       NormalisableRange<float> (-24.0f, -5.0f, 0.1f), -10.0f,
                                                       AudioParameterFloatAttributes().withLabel ("LUFS-S")));

    layout.add (std::make_unique<AudioParameterFloat> (ParameterID { "ceiling", 1 }, "True Peak Ceiling",
                                                       NormalisableRange<float> (-6.0f, 0.0f, 0.1f), -1.0f,
                                                       AudioParameterFloatAttributes().withLabel ("dBTP")));

    layout.add (std::make_unique<AudioParameterFloat> (ParameterID { "maxgain", 1 }, "Max Gain",
                                                       NormalisableRange<float> (0.0f, 30.0f, 0.1f), 18.0f,
                                                       AudioParameterFloatAttributes().withLabel ("dB")));

    layout.add (std::make_unique<AudioParameterFloat> (ParameterID { "speed", 1 }, "Speed",
                                                       NormalisableRange<float> (3.0f, 30.0f, 0.1f), 8.0f,
                                                       AudioParameterFloatAttributes().withLabel ("s")));

    layout.add (std::make_unique<AudioParameterFloat> (ParameterID { "release", 1 }, "Limiter Release",
                                                       NormalisableRange<float> (20.0f, 500.0f, 1.0f), 150.0f,
                                                       AudioParameterFloatAttributes().withLabel ("ms")));

    layout.add (std::make_unique<AudioParameterBool> (ParameterID { "hold", 1 }, "Hold Gain", false));
    layout.add (std::make_unique<AudioParameterBool> (ParameterID { "bypass", 1 }, "Bypass", false));

    return layout;
}

AutoMasterAudioProcessor::AutoMasterAudioProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput ("Input", juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMS", createLayout())
{
}

bool AutoMasterAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto& in = layouts.getMainInputChannelSet();
    const auto& out = layouts.getMainOutputChannelSet();
    return (out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo()) && in == out;
}

void AutoMasterAudioProcessor::prepareToPlay (double sampleRate, int)
{
    sampleRateHz = sampleRate;
    const int ch = juce::jmax (1, getTotalNumInputChannels());

    meter.prepare (sampleRate, ch);
    limiter.prepare (sampleRate, ch, 3.0);
    setLatencySamples (limiter.getLatencySamples());

    gainDb = 0.0f;
    gainTargetLin = 1.0f;
    gainSmoothed = 1.0f;
    smoothCoef = 1.0f - std::exp (-1.0f / (float) (sampleRate * 0.05)); // 50 ms gain smoothing
}

void AutoMasterAudioProcessor::updateControl (float targetLufs, float tauSeconds, float maxGainDb, bool hold, bool bypass)
{
    gainDb = juce::jlimit (-24.0f, maxGainDb, gainDb);

    // Adapt only with enough signal above the gate (>= 1 s) and when not frozen
    if (! bypass && ! hold && meter.getValidBlocks() >= 10)
    {
        const float error = targetLufs - meter.getShortTermLoudness();
        const float step = juce::jlimit (-0.5f, 0.5f, error * (0.1f / tauSeconds)); // runs every 100 ms
        gainDb = juce::jlimit (-24.0f, maxGainDb, gainDb + step);
    }

    gainTargetLin = std::pow (10.0f, gainDb / 20.0f);
}

void AutoMasterAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int numSamples = buffer.getNumSamples();
    for (int c = getTotalNumInputChannels(); c < getTotalNumOutputChannels(); ++c)
        buffer.clear (c, 0, numSamples);

    const int numCh = juce::jmin (buffer.getNumChannels(), 2);
    if (numCh < 1)
        return;

    if (resetRequested.exchange (false))
    {
        meter.reset();
        limiter.reset();
        gainDb = 0.0f;
        gainTargetLin = 1.0f;
        gainSmoothed = 1.0f;
    }

    const float target = apvts.getRawParameterValue ("target")->load();
    const float ceiling = apvts.getRawParameterValue ("ceiling")->load();
    const float maxGain = apvts.getRawParameterValue ("maxgain")->load();
    const float tau = apvts.getRawParameterValue ("speed")->load();
    const float release = apvts.getRawParameterValue ("release")->load();
    const bool hold = apvts.getRawParameterValue ("hold")->load() > 0.5f;
    const bool bypass = apvts.getRawParameterValue ("bypass")->load() > 0.5f;

    limiter.setCeilingDb (ceiling);
    limiter.setReleaseMs (release);

    float* data[2] = { buffer.getWritePointer (0), numCh > 1 ? buffer.getWritePointer (1) : nullptr };
    float minGain = 1.0f;

    for (int i = 0; i < numSamples; ++i)
    {
        gainSmoothed += (gainTargetLin - gainSmoothed) * smoothCoef;
        const float g = bypass ? 1.0f : gainSmoothed;

        float frame[2] = { 0.0f, 0.0f };
        for (int c = 0; c < numCh; ++c)
            frame[c] = data[c][i] * g;

        limiter.processFrame (frame, ! bypass);

        for (int c = 0; c < numCh; ++c)
            data[c][i] = frame[c];

        minGain = juce::jmin (minGain, limiter.getLastGain());

        // The loudness is measured AFTER the limiter, so the loop sees what really leaves the plugin
        if (meter.processFrame (frame))
            updateControl (target, tau, maxGain, hold, bypass);
    }

    meterShortTerm.store (meter.getShortTermLoudness());
    meterGainDb.store (gainDb);
    meterReductionDb.store (-20.0f * std::log10 (juce::jmax (minGain, 1.0e-4f)));
}

juce::AudioProcessorEditor* AutoMasterAudioProcessor::createEditor()
{
    return new AutoMasterAudioProcessorEditor (*this);
}

void AutoMasterAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, destData);
}

void AutoMasterAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new AutoMasterAudioProcessor();
}

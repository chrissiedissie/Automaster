#pragma once
#include "PluginProcessor.h"

class AutoMasterAudioProcessorEditor : public juce::AudioProcessorEditor,
                                       private juce::Timer
{
public:
    explicit AutoMasterAudioProcessorEditor (AutoMasterAudioProcessor&);
    ~AutoMasterAudioProcessorEditor() override = default;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;

    struct Knob
    {
        juce::Slider slider;
        juce::Label label;
        std::unique_ptr<SliderAttachment> attachment;
    };

    void setupKnob (Knob&, const juce::String& text, const juce::String& paramId, const juce::String& suffix);
    void timerCallback() override;

    AutoMasterAudioProcessor& proc;

    Knob targetKnob, ceilingKnob, maxGainKnob, speedKnob, releaseKnob;
    juce::ToggleButton holdButton { "Hold gain" }, bypassButton { "Bypass" };
    juce::TextButton resetButton { "Reset" };
    juce::Label readout;

    std::unique_ptr<ButtonAttachment> holdAttachment, bypassAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (AutoMasterAudioProcessorEditor)
};

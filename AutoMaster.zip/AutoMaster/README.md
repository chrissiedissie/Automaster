# AutoMaster – automatisches Loudness-/True-Peak-Plugin

Bringt das Signal automatisch auf **-10 LUFS (Short-Term)** und begrenzt es auf **-1 dBTP (True Peak)**.

Formate: **VST3** (Windows + macOS, z. B. Reaper), **AU** (macOS, für Logic Pro), Standalone.

## So funktioniert es

1. Das Plugin misst die Lautheit **hinter dem Limiter** (ITU-R BS.1770-4, K-Gewichtung, 3-s-Fenster).
2. Ein langsamer Regler (Parameter *Speed*) hebt oder senkt den Gain, bis der Short-Term-Wert beim Ziel liegt.
3. Ein Lookahead-Limiter mit 8x Oversampling hält den True Peak unter dem Ceiling (intern 0,3 dB Sicherheitsabstand).

Das Plugin meldet 3 ms + 11 Samples Latenz, Reaper und Logic gleichen das automatisch aus.

## Bauen

### Variante A: GitHub Actions (kein lokales Setup)
1. Ordner in ein GitHub-Repository pushen (`build.yml` nach `.github/workflows/build.yml`).
2. Tab **Actions** -> Lauf öffnen -> unter **Artifacts** die Windows- und macOS-Version herunterladen.

### Variante B: lokal
Voraussetzungen: CMake 3.22+, Visual Studio 2022 (Windows) bzw. Xcode (macOS), Internet (lädt JUCE).

    cmake -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build --config Release

Ergebnis in `build/AutoMaster_artefacts/Release/`.

## Installieren

| System  | Format | Ordner |
|---------|--------|--------|
| Windows | VST3 | `C:\Program Files\Common Files\VST3` |
| macOS   | VST3 | `~/Library/Audio/Plug-Ins/VST3` |
| macOS   | AU (Logic) | `~/Library/Audio/Plug-Ins/Components` |

macOS blockiert unsignierte Plugins: `xattr -cr ~/Library/Audio/Plug-Ins/Components/AutoMaster.component`
(entsprechend für `.vst3`). Danach Logic neu starten (ggf. Plug-in-Verwaltung -> Neu scannen).

## Benutzung

- Als **letztes Plugin** auf den Master-Bus oder die Spur legen.
- Der Gain braucht einige Sekunden, bis er einschwingt. Zum Rendern am besten kurz vorlaufen lassen, dann **Hold gain** aktivieren, damit der Gain konstant bleibt.
- *Max Gain* begrenzt die Anhebung. Sehr dynamisches Material wird bei -10 LUFS stark vom Limiter bearbeitet.
- *Reset* setzt Gain und Messung zurück (z. B. beim Wechsel auf einen neuen Song).

## Parameter

Target (-24 bis -5 LUFS-S, Standard -10), Ceiling (-6 bis 0 dBTP, Standard -1), Max Gain (0 bis 30 dB), Speed (3 bis 30 s), Limiter Release (20 bis 500 ms), Hold gain, Bypass.

#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <array>
#include <cmath>

// ITU-R BS.1770-4 loudness: K-weighting, 100 ms blocks, 3 s short-term window.
// The short-term value only averages blocks above an absolute gate of -70 LUFS,
// so silence before/after the music does not pull the reading down.
class LoudnessMeter
{
public:
    static constexpr int maxChannels = 2;
    static constexpr int blocksPerWindow = 30; // 30 x 100 ms = 3 s

    void prepare (double sampleRate, int numChannels)
    {
        channels = juce::jlimit (1, maxChannels, numChannels);
        blockLength = juce::jmax (1, (int) std::lround (sampleRate * 0.1));
        setupFilters (sampleRate);
        reset();
    }

    void reset()
    {
        for (int c = 0; c < maxChannels; ++c)
        {
            shelf[c].reset();
            highpass[c].reset();
            blockSum[c] = 0.0;
        }
        blockCount = 0;
        blockPos = 0;
        blockEnergy.fill (0.0);
        shortTerm = -100.0f;
        validBlocks = 0;
    }

    // frame[0..channels-1]. Returns true whenever a new 100 ms block was completed.
    bool processFrame (const float* frame)
    {
        for (int c = 0; c < channels; ++c)
        {
            const double y = highpass[c].process (shelf[c].process ((double) frame[c]));
            blockSum[c] += y * y;
        }

        if (++blockCount < blockLength)
            return false;

        double energy = 0.0;
        for (int c = 0; c < channels; ++c)
        {
            energy += blockSum[c] / (double) blockLength;
            blockSum[c] = 0.0;
        }

        blockCount = 0;
        blockEnergy[(size_t) blockPos] = energy;
        blockPos = (blockPos + 1) % blocksPerWindow;
        updateShortTerm();
        return true;
    }

    float getShortTermLoudness() const noexcept { return shortTerm; }
    int getValidBlocks() const noexcept { return validBlocks; }

private:
    struct Biquad
    {
        double b0 = 1.0, b1 = 0.0, b2 = 0.0, a1 = 0.0, a2 = 0.0, z1 = 0.0, z2 = 0.0;

        double process (double x) noexcept
        {
            const double y = b0 * x + z1;
            z1 = b1 * x - a1 * y + z2;
            z2 = b2 * x - a2 * y;
            return y;
        }

        void reset() noexcept { z1 = z2 = 0.0; }
    };

    void setupFilters (double fs)
    {
        const double pi = juce::MathConstants<double>::pi;

        // Stage 1: high shelf ("head" filter)
        {
            const double f0 = 1681.974450955533, G = 3.999843853973347, Q = 0.7071752369554196;
            const double K = std::tan (pi * f0 / fs);
            const double Vh = std::pow (10.0, G / 20.0);
            const double Vb = std::pow (Vh, 0.4996667741545416);
            const double a0 = 1.0 + K / Q + K * K;

            Biquad s;
            s.b0 = (Vh + Vb * K / Q + K * K) / a0;
            s.b1 = 2.0 * (K * K - Vh) / a0;
            s.b2 = (Vh - Vb * K / Q + K * K) / a0;
            s.a1 = 2.0 * (K * K - 1.0) / a0;
            s.a2 = (1.0 - K / Q + K * K) / a0;
            for (int c = 0; c < maxChannels; ++c)
                shelf[c] = s;
        }

        // Stage 2: RLB high-pass
        {
            const double f0 = 38.13547087602444, Q = 0.5003270373238773;
            const double K = std::tan (pi * f0 / fs);
            const double a0 = 1.0 + K / Q + K * K;

            Biquad h;
            h.b0 = 1.0;
            h.b1 = -2.0;
            h.b2 = 1.0;
            h.a1 = 2.0 * (K * K - 1.0) / a0;
            h.a2 = (1.0 - K / Q + K * K) / a0;
            for (int c = 0; c < maxChannels; ++c)
                highpass[c] = h;
        }
    }

    void updateShortTerm()
    {
        const double absGate = std::pow (10.0, (-70.0 + 0.691) / 10.0);
        double sum = 0.0;
        int n = 0;

        for (double e : blockEnergy)
            if (e > absGate)
            {
                sum += e;
                ++n;
            }

        validBlocks = n;
        shortTerm = n > 0 ? (float) (-0.691 + 10.0 * std::log10 (sum / (double) n)) : -100.0f;
    }

    std::array<Biquad, maxChannels> shelf, highpass;
    std::array<double, maxChannels> blockSum {};
    std::array<double, blocksPerWindow> blockEnergy {};
    int channels = 2, blockLength = 4800, blockCount = 0, blockPos = 0, validBlocks = 0;
    float shortTerm = -100.0f;
};
